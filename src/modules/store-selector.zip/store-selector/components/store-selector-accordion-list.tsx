import React, { useState } from 'react';
import { IFullOrgUnitAvailability } from '@msdyn365-commerce-modules/retail-actions';

interface Props {
    data: { countries: { [key: string]: { [key: string]: IFullOrgUnitAvailability[] } } };
    onStateSelected: (locations: IFullOrgUnitAvailability[]) => void;
}

const StoreSelectorAccordionList: React.FC<Props> = ({ data, onStateSelected }) => {
    const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
    const [selectedState, setSelectedState] = useState<string | null>(null);

    const toggleCountry = (country: string) => {
        if (selectedCountry === country) {
            setSelectedCountry(null);
            setSelectedState(null);
            onStateSelected([]);
        } else {
            setSelectedCountry(country);
            setSelectedState(null);
            onStateSelected([]);
        }
    };

    const toggleState = (country: string, state: string) => {
        if (selectedState === state) {
            setSelectedState(null);
            onStateSelected([]);
        } else {
            setSelectedState(state);
            onStateSelected(data.countries[country][state]);
        }
    };

    return (
        <div>
            {Object.keys(data.countries).map(country => (
                <div key={country}>
                    <h2 onClick={() => toggleCountry(country)}>{country}</h2>
                    {selectedCountry === country && (
                        <div>
                            {Object.keys(data.countries[country]).map(state => (
                                <div key={state}>
                                    <h3 onClick={() => toggleState(country, state)}>{state}</h3>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

export default StoreSelectorAccordionList;
